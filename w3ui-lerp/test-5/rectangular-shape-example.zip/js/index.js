function draw() {
  const canvas = document.querySelector('canvas');
  const ctx = canvas.getContext('2d');
  const steps = 300;
  const w = canvas.width;
  const h = canvas.height;
  ctx.fillStyle = 'yellow';
  ctx.fillRect(0, 0, w, h);
  const bouncer_fn = make_bouncer_fn(8);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.lineTo(w, h);
  ctx.stroke();
  ctx.beginPath();
  for (let i = 0; i < steps; ++i) {
    const x = i / steps;
    const y = bouncer_fn(x);
    ctx.lineTo(x * w, h - y * h);
  }
  ctx.stroke();
}

function make_bouncer_fn(n) {
  const sector_width = 1 / n;
  
  return function (x) {
    const s = (x == 1) ? (n - 1) : Math.floor(x / sector_width);
    const xa = ((s == n - 1) ? 1 : 2) * (x / sector_width - s) - 1;
    const a = sector_width * (s + 1);
    return a * (1 - xa * xa);
  }
}